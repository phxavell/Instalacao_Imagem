import odoo_queries as qr

aaa = qr.notebook_serial_duplicado()

print(aaa)


