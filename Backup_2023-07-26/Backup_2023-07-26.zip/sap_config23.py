#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Credentials for SAP
"""

URL = 'https://177.85.33.53:50579/b1s/v1/Login'
COMPANYDB = 'SBO_AVELL_PRD'                                #ALTERAR COMPANHIA -- (SELECIONAR A EMPRESA NO LOGIN)
USERNAME = 'manager'
PASSWORD = 'Ramo01'
