#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Credentials for SAP
"""

URL = 'https://avell.ramo.com.br:50000/b1s/v1/Login'
COMPANYDB = 'SBO_AVELL_PRD'                                #ALTERAR COMPANHIA -- (SELECIONAR A EMPRESA NO LOGIN)
USERNAME = 'manager'
PASSWORD = 'Ramo01'
