#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Credentials for Avell Odoo
"""

URL = 'https://odoo.avell.com'
DATABASE = 'producao12'
USERNAME = 'avellscripts'
PASSWORD = 'P1rarucuAtomic0'
